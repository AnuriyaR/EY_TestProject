package StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.Given;

public class StepDefinition {
	
	WebDriver driver ;
	
	
	

	
	
	
	@Given("Open given URL in Browser")
	public void user_is_on_login_page() throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\rakpa\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe"); 
	 //System.out.println("Test1234");
	 driver = new ChromeDriver();
	 driver.get("http://automationpractice.com");
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//a[@class='login']")).click();
	 Thread.sleep(3000);
	 
	 
	 driver.findElement(By.xpath("//input[@id='email_create']")).sendKeys("priyankapatil5721@gmail.com");
	 Thread.sleep(3000);
	 
	 driver.findElement(By.xpath("//*[@id=\"SubmitCreate\"]/span/i")).click();
	 Thread.sleep(5000);
	 
	 
	// WebElement radio1= driver.findElement(By.xpath("//input[@id='id_gender']"));
	 
	 driver.manage().window().maximize();
	 Thread.sleep(3000);
	 
	 WebElement radio1= driver.findElement(By.id("id_gender2"));

	
   radio1.click();
   Thread.sleep(3000);
	 
	 
    driver.findElement(By.name("customer_firstname")).sendKeys("Priyanka");	
    Thread.sleep(3000);
    
    driver.findElement(By.name("customer_lastname")).sendKeys("Patil");	
    Thread.sleep(3000);
	 
    driver.findElement(By.name("passwd")).sendKeys("Anu@123!");
    Thread.sleep(3000);
    
    
    //WebElement developers_dropdown = driver.findElement(By.id("developers-menu-toggle"))
   
  /* Select days =new Select(driver.findElement(By.xpath("//*[@id='days']")));
   
    days.selectByVisibleText("30");
    
    Select months=new Select(driver.findElement(By.id("months")));
    months.selectByVisibleText("June");
    
    Select years=new Select(driver.findElement(By.id("years")));
    years.selectByVisibleText("1991");
    */
    
    driver.findElement(By.xpath("//*[@id=\"id_state\"]")).click();
    
    
    Select state1=new Select(driver.findElement(By.id("id_state")));
    state1.selectByVisibleText("Florida");
    
    Thread.sleep(3000); 
    
    driver.findElement(By.id("address1")).sendKeys("strt 5 , 2319, inf ltd., etc.");
    Thread.sleep(3000);
    
    driver.findElement(By.id("city")).sendKeys("Tampa");
    Thread.sleep(3000);
    
    driver.findElement(By.id("postcode")).sendKeys("33601");
    Thread.sleep(3000);
     
    Select country=new Select(driver.findElement(By.id("id_country")));
    country.selectByVisibleText("United States");
    
    driver.findElement(By.id("phone_mobile")).sendKeys("1234567890");
    
    
   driver.findElement (By.id("alias")).sendKeys("strt 5, 2319, inf ltd.,");
   Thread.sleep(3000);
	 
    driver.findElement(By.id("submitAccount")).submit();
    Thread.sleep(3000);
 
	 //driver.close();
    		
	 
	}
}
