package Runner;

import org.junit.runner.RunWith;
import cucumber.api.*;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "C:\\Users\\rakpa\\eclipse-workspace\\TestProject\\src\\test\\java\\Features\\Test.feature"
		,glue={"StepDefinition"}
		)


public class runner {

}
